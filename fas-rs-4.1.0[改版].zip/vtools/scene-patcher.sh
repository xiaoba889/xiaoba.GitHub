DIR=${0%/*}
MODDIR=$(dirname $DIR)
SCENE_DIR=/data/data/com.omarea.vtools/files
alias jq=$DIR/jq
scene_daemon=`pgrep -f "scene-daemon"`
patch=$(sed -n '1p' "$DIR/patch")
fas_rs_version=$(grep '^version=' "$MODDIR/module.prop" | cut -d '=' -f2)
fas_rs_codename=$(grep '^versionCodeName=' "$MODDIR/module.prop" | cut -d '=' -f2)
mod_version=$(grep '^mod_version=' "$MODDIR/module.prop" | cut -d '=' -f2)
mod_codename=$(grep '^mod_versionCodeName=' "$MODDIR/module.prop" | cut -d '=' -f2)
fas_rs_author=$(grep '^fas_rs_author=' "$MODDIR/module.prop" | cut -d '=' -f2)
fas_rs_mod_author=$(grep '^fas_rs_mod_author=' "$MODDIR/module.prop" | cut -d '=' -f2)
scene_version=$(jq -r '.version' $SCENE_DIR/manifest.json)
scene_author=$(grep '^scene_author=' "$MODDIR/module.prop" | cut -d '=' -f2)
mod_exist=$(grep "fas_rs_mod" "$SCENE_DIR/manifest.json")

if [ ! -d "$SCENE_DIR" ]; then
    exit 0
elif [ ! -n "$mod_exist" ]; then
    touch $DIR/tmp
    cp -f $DIR/_FASRS.json $SCENE_DIR && chmod a+rwx $SCENE_DIR/_FASRS.json
    sed -i '/games/,$d' $SCENE_DIR/profile.json && echo $patch >> $SCENE_DIR/profile.json
    jq '.alias.fas_rs = "/dev/fas_rs/mode"' $SCENE_DIR/profile.json | jq '.schemes.powersave.game = []' | jq '.schemes.balance.game = []' | jq '.schemes.performance.game = []' | jq '.schemes.fast.game = []' | jq '.schemes.pedestal.game = []' > $DIR/tmp && cp -f $DIR/tmp $SCENE_DIR/profile.json && chmod a+rwx $SCENE_DIR/profile.json
    jq '.version = "\n🐶 - (scene-patcher) fas-rs-mod: _mod_version_ (_mod_codename_ / @_fas_rs_mod_author_)\n🐷 - (in-games) fas-rs: _fas_rs_version_ (_fas_rs_codename_ / @_fas_rs_author_)\n🛠 - (in-applications) scene:‭⁧(_scene_version_ / @_scene_author_) ⁧"' $SCENE_DIR/manifest.json | jq '.features.pedestal = true' | jq '.features.fas = false' | jq '.features.fas_rs_mod = true' > $DIR/tmp
    cp -f $DIR/tmp $SCENE_DIR/manifest.json
    sed -e "s/_fas_rs_version_/$fas_rs_version/" -e "s/_fas_rs_codename_/$fas_rs_codename/" -e "s/_mod_version_/$mod_version/" -e "s/_mod_codename_/$mod_codename/" -e "s/_fas_rs_mod_author_/$fas_rs_mod_author/" -e "s/_fas_rs_author_/$fas_rs_author/" -e "s/_scene_version_/$scene_version/" -e "s/_scene_author_/$scene_author/" $SCENE_DIR/manifest.json > $DIR/tmp && cp -f $DIR/tmp $SCENE_DIR/manifest.json && chmod a+rwx $SCENE_DIR/manifest.json
    rm -rf $DIR/tmp
    kill -9 $scene_daemon 2>/dev/null
fi